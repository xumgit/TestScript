var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
var MaxTemp = {},
    MinTemp = {},
    allDays = [];
var city_json;
//Cities
var city_arr = new Array();
$(document).ready(function() {
    // SimpleWeather report
    $("#city_search").on('input', function(event) {
        // if(event.keyCode == 8){
        if (event.originalEvent.inputType == "deleteContentBackward") {
            return;
        } else {
            city_json = [];
            var param = document.getElementById('city_search').value;
            if (param.length <= 3) {
                // show_alert_message_popup("Error", 'Please enter more characters');
                return;
            } else {
                var jsonurl = "" + base_url + "/sites/all/modules/tpvision/gadgets/city_list.json";
                //show the loading symbol till the search is happening
                $(".autocomplete .delete-loading").show();
                $.getJSON(jsonurl, function(jsonObject) {
                    city_json = jQuery.grep(jsonObject, function(city, i) {
                        var re = new RegExp(param, 'gi');
                        return (city.name.match(re));
                    });
                    $(".autocomplete .delete-loading").hide();
                    city_arr = [];
                    city_json.forEach(function(city_names, i) {
                        city_arr.push(city_names.name + ',' + city_names.country);
                    });
                    // populateCities();
                    autocomplete(document.getElementById("city_search"), city_arr);
                }).error();
            }
        }
    });
    // autocomplete(document.getElementById("city_search"), monthNames);

    if ($(".weather-gadget").length) {
        $(".weather-gadget").each(function() {
            var id = $(this).parent().attr("id");
            weather_widget_gadget_script("#" + id);
        });
    }
    //Added the weatherFive widget script 
    if ($(".weatherFive-gadget").length) {
        $(".weatherFive-gadget").each(function() {
            var id = $(this).parent().attr("id");
            weatherFive_widget_gadget_script('#' + id);
        });
    }
    //Digital clock
    if ($(".gadget-object .clock").length) {
        $(".gadget-object .clock").each(function() {
            var id = $(this).parent().attr('id');
            digital_clock_gadget_script(id);
        });
    }
});
// Create two variable with the names of the months and days in an array
function digital_clock_gadget_script(id) {
    if (!$(".widget .gadget-object .clock").length) {
        return false;
    }
    var timeCall = null;
    setInterval(function() {
        //returning null values if current page do not have the clock widget
        if (!$(".widget .gadget-object .clock").length) {
            return false;
        }
        //  ClockControl(function(mDate) {
        var newDate = ClockControl();
        var format = $('#' + id + ' #gadget-date').attr("format");
        if (format == "accor-date") {
            var day = dayNames[newDate.getDay()];
            var mon = monthNames[newDate.getMonth()];
            var minutes = newDate.getMinutes();
            minutes = (minutes < 10 ? "0" : "") + minutes;
            var hours = newDate.getHours();
            hours = (hours < 10 ? "0" : "") + hours
            var format = day + ", " + mon + " " + newDate.getDate() + " " + hours + ":" + minutes;
            $('#' + id + ' #gadget-date').html(format);
        } else if (format == "accor-date1") {
            var day = dayNames[newDate.getDay()];
            var mon = monthNames[newDate.getMonth()];
            var minutes = newDate.getMinutes();
            minutes = (minutes < 10 ? "0" : "") + minutes;
            var hours = newDate.getHours();
            hours = (hours < 10 ? "0" : "") + hours
            var format = day + ", " + newDate.getDate() + " " + mon + " " + newDate.getFullYear() + " " + hours + ":" + minutes;
            $('#' + id + ' #gadget-date').html(format);
        } else {
            if (format != "" && format != undefined) {
                var format1 = format.replace("dd", newDate.getDate()).replace("mm", (newDate.getMonth() + 1)).replace("yyyy", newDate.getFullYear());
                $('#' + id + ' #gadget-date').html(format1);
            } else {
                $('#' + id + ' #gadget-date').html(newDate.getDate() + '-' + (newDate.getMonth() + 1) + '-' + newDate.getFullYear());
            }
            var seconds = newDate.getSeconds();
            // Add a leading zero to seconds value
            $('#' + id + ' #sec').html((seconds < 10 ? "0" : "") + seconds);
            var minutes = newDate.getMinutes();
            // Add a leading zero to the minutes value
            $('#' + id + ' #min').html((minutes < 10 ? "0" : "") + minutes);
            var hours = newDate.getHours();
            // Add a leading zero to the hours value
            $('#' + id + ' #hours').html((hours < 10 ? "0" : "") + hours);
            //});
        }
    }, 1000);
}

function weather_widget_gadget_script(id) {
    var city = $(id + ' .gadget').attr("city");
    var temp = $(id + ' .gadget').attr("temperature");
    console.log("city : " + city);

    $.simpleWeather({
        location: city,
        woeid: '',
        unit: temp,
        success: function(weather) {
            html = '<div class="weather"><i class="icon-' + weather.code + '"></i> ' + weather.temp + '&deg;' + weather.units.temp + '</div>';
            $(id + " .weather-gadget .temperature").html(html);
            html = '<ul><li>' + weather.city + ', ' + weather.region + '</li>';
            html += '<li class="currently">' + weather.currently + '</li>';
            html += '<li>' + weather.wind.direction + ' ' + weather.wind.speed + ' ' + weather.units.speed + '</li></ul>';
            $(id + " .weather-gadget .details").html(html);
        },
        error: function(error) {
            //$(".weather-gadget").html('<p>'+error+'</p>');
        }
    });
}

function weatherFive_widget_gadget_script(id) {
    var count = 0;
    MaxTemp = {}, MinTemp = {}, allDays = [];
    var str = $(id + ' .gadget').attr("city");
    var city = str.split(',')
    var html = '';
    var now = new Date();
    var day = now.getDay();
    var temp_sign = $(id + ' .gadget').attr("temperature");
    $.getJSON("http://api.openweathermap.org/data/2.5/forecast?q=" + city[0] + "," + city[1] + "&lang=en&units=metric&APPID=d5e367417991dc934345c23b485d4ca3", function(json) {
        //get the maximum temperature
        getMaxMinTemp(json);
        //reset the alldays array for min temp functionality
        //get the minimum temprature 
        //getMinTemp(json);
        json.list.forEach(function(forecast, i) {
            var currHour = now.getHours();
            var apiTime = forecast.dt_txt.split(' ');
            var hour = apiTime[1].split(':');
            var getTime = getCurrData(currHour);
            if (hour[0] == getTime) {
                count++;
                if (count == 1) {
                    $(id + ' .inner-top-left .weather-icon img').attr('src', "https://openweathermap.org/themes/openweathermap/assets/vendor/owm/img/widgets/" + forecast.weather[0].icon + ".png");
                    $(id + ' .inner-top-left .weather-city').html(dayNames[day] + ", " + city[0] + "  " + city[1]);

                    if (temp_sign == 'f') {
                        var temp = Math.round(forecast.main.temp * 9 / 5 + 32);
                        var temp_html = " " + temp + String.fromCharCode(176) + 'F' + "  ";
                    } else {
                        var temp_html = " " + Math.round(forecast.main.temp) + String.fromCharCode(176) + 'C' + "  ";
                    }
                    $(id + ' .inner-top-right .first-day-temp').html(temp_html);
                    $(id + ' .inner-top-right .first-day-type').html(forecast.weather[0].description + " ");
                    html = " wind " + Math.round(forecast.wind.speed) + " m/s ";

                    $(id + ' .inner-top-right .first-day-description').html(html);
                }
                //check if the day is starts from 2nd 
                if (count >= 2) {
                    //to get the current day + next 4 days, checking condition for days not more than 6
                    if (day <= 6) {
                        day++;
                        if (day == 7) {
                            day = 0
                        }
                    }
                    $(id + ' .downwrap .weather-day-' + count + ' .downwrap-day').text(dayNames[day]);
                    $(id + ' .downwrap .weather-day-' + count + ' .downwrap-icon img').attr('src', "https://openweathermap.org/themes/openweathermap/assets/vendor/owm/img/widgets/" + forecast.weather[0].icon + ".png");
                    if (temp_sign == 'f') {
                        var temp_min = Math.round(MinTemp[apiTime[0]] * 9 / 5 + 32);
                        var temp_max = Math.round(MaxTemp[apiTime[0]] * 9 / 5 + 32);
                        $(id + ' .downwrap .weather-day-' + count + ' .downwrap-temp').text(temp_min + String.fromCharCode(176) + "/" + temp_max + String.fromCharCode(176) + 'F');
                    } else {
                        $(id + ' .downwrap .weather-day-' + count + ' .downwrap-temp').text(Math.round(MinTemp[apiTime[0]]) + String.fromCharCode(176) + "/" + Math.round(MaxTemp[apiTime[0]]) + String.fromCharCode(176) + 'C');
                    }
                }
            }
        });
    }).error(function() {
        $(id + ' .weatherFive-gadget .mainwrap').html('<img src="' + base_url + '/sites/all/themes/tpvision/images/no-internet.png" alt="No Internet Conntection">');
    });
}

function getCurrData(currHour) {
    var rem = (currHour % 3);
    var Time;
    if (rem == 0) {
        Time = currHour;
    } else {
        Time = currHour + (3 - rem);
    }
    return Time;
}

function getMaxMinTemp(json) {
    var count = 0;
    json.list.forEach(function(forecast, i) {
        var currDate = forecast.dt_txt.split(' ')[0];
        if (jQuery.inArray(currDate, allDays) == -1) {
            count++;
            allDays[count] = currDate;
            MaxTemp[currDate] = 0, MinTemp[currDate] = 200;
        } else {
            if (forecast.main.temp_max > MaxTemp[currDate]) {
                MaxTemp[currDate] = forecast.main.temp_max;
            }
            if (forecast.main.temp_min < MinTemp[currDate]) {
                MinTemp[currDate] = forecast.main.temp_min;
            }
        }
    });
}


function autocomplete(inp, arr) {
    /*the autocomplete function takes two arguments,
    the text field element and an array of possible autocompleted values:*/
    var currentFocus;
    /*execute a function when someone writes in the text field:*/
    // inp.addEventListener("input", function(e) {
    var a, b, i, val = inp.value;
    /*close any already open lists of autocompleted values*/
    closeAllLists();
    if (!val) { return false; }
    currentFocus = -1;
    /*create a DIV element that will contain the items (values):*/
    a = document.createElement("DIV");
    a.setAttribute("id", inp.id + "autocomplete-list");
    a.setAttribute("class", "autocomplete-items");
    /*append the DIV element as a child of the autocomplete container:*/
    inp.parentNode.appendChild(a);
    /*for each item in the array...*/
    for (i = 0; i < arr.length; i++) {
        /*check if the item starts with the same letters as the text field value:*/
        if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
            /*create a DIV element for each matching element:*/
            b = document.createElement("DIV");
            /*make the matching letters bold:*/
            b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
            b.innerHTML += arr[i].substr(val.length);
            /*insert a input field that will hold the current array item's value:*/
            b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
            /*execute a function when someone clicks on the item value (DIV element):*/
            b.addEventListener("click", function(e) {
                /*insert the value for the autocomplete text field:*/
                inp.value = this.getElementsByTagName("input")[0].value;
                /*close the list of autocompleted values,
                (or any other open lists of autocompleted values:*/
                closeAllLists();
            });
            a.appendChild(b);
        }
    }
    // });
    /*execute a function presses a key on the keyboard:*/
    inp.addEventListener("keydown", function(e) {
        var x = document.getElementById(this.id + "autocomplete-list");
        if (x) x = x.getElementsByTagName("div");
        if (e.keyCode == 40) {
            /*If the arrow DOWN key is pressed,
            increase the currentFocus variable:*/
            currentFocus++;
            /*and and make the current item more visible:*/
            addActive(x);
        } else if (e.keyCode == 38) { //up
            /*If the arrow UP key is pressed,
            decrease the currentFocus variable:*/
            currentFocus--;
            /*and and make the current item more visible:*/
            addActive(x);
        } else if (e.keyCode == 13) {
            /*If the ENTER key is pressed, prevent the form from being submitted,*/
            e.preventDefault();
            if (currentFocus > -1) {
                /*and simulate a click on the "active" item:*/
                if (x) {
                    inp.value = $('.autocomplete-items .autocomplete-active input').val();
                    /*close the list of autocompleted values,
                    (or any other open lists of autocompleted values:*/
                    closeAllLists();
                }
                // x[currentFocus].click();
            }
        }
    });

    function addActive(x) {
        /*a function to classify an item as "active":*/
        if (!x) return false;
        /*start by removing the "active" class on all items:*/
        removeActive(x);
        if (currentFocus >= x.length) currentFocus = 0;
        if (currentFocus < 0) currentFocus = (x.length - 1);
        /*add class "autocomplete-active":*/
        x[currentFocus].classList.add("autocomplete-active");
    }

    function removeActive(x) {
        /*a function to remove the "active" class from all autocomplete items:*/
        for (var i = 0; i < x.length; i++) {
            x[i].classList.remove("autocomplete-active");
        }
    }

    function closeAllLists(elmnt) {
        /*close all autocomplete lists in the document,
        except the one passed as an argument:*/
        var x = document.getElementsByClassName("autocomplete-items");
        for (var i = 0; i < x.length; i++) {
            if (elmnt != x[i] && elmnt != inp) {
                x[i].parentNode.removeChild(x[i]);
            }
        }
    }
    /*execute a function when someone clicks in the document:*/
    document.addEventListener("click", function(e) {
        closeAllLists(e.target);
    });
}
//End of function autocomplete